using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Internet_Rulle_Database.Data;
using Internet_Rulle_Database;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<Internet_Rulle_DatabaseContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Internet_Rulle_DatabaseContext") ?? throw new InvalidOperationException("Connection string 'Internet_Rulle_DatabaseContext' not found.")));

//builder.Services.AddScoped<MovieSeeder>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    //Anv�nd f�r att seeda filmdatan till databasen
    //var movieSeeder = services.GetRequiredService<MovieSeeder>();

    //movieSeeder.Seed();
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
