﻿using Microsoft.EntityFrameworkCore;
using Internet_Rulle_Database.Model;

namespace Internet_Rulle_Database.Data
{
    public class Internet_Rulle_DatabaseContext : DbContext
    {
        public Internet_Rulle_DatabaseContext(DbContextOptions<Internet_Rulle_DatabaseContext> options)
            : base(options)
        {
        }

        public DbSet<MovieModel> Movies { get; set; } 
    }
}