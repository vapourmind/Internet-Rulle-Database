﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Internet_Rulle_Database.Data;
using Internet_Rulle_Database.Model;

namespace Internet_Rulle_Database.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieModelController : ControllerBase
    {
        private readonly Internet_Rulle_DatabaseContext _context;

        public MovieModelController(Internet_Rulle_DatabaseContext context)
        {
            _context = context;
        }

        [HttpGet("movies")]
        public async Task<ActionResult<IEnumerable<MovieModel>>> GetMovies()
        {
            return await _context.Movies.ToListAsync();
        }

        [HttpGet("movies/{id}")]
        public async Task<ActionResult<MovieModel>> GetMovie(int id)
        {
            var movieModel = await _context.Movies.FindAsync(id);

            if (movieModel == null)
            {
                return NotFound();
            }

            return movieModel;
        }

        [HttpPost("movies")]
        public async Task<ActionResult<MovieModel>> AddMovie(MovieModel movieModel)
        {
            _context.Movies.Add(movieModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetMovie), new { id = movieModel.Id }, movieModel);
        }

        [HttpPut("movies/{id}")]
        public async Task<IActionResult> UpdateMovie(int id, MovieModel movieModel)
        {
            if (id != movieModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(movieModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MovieModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("movies/{id}")]
        public async Task<IActionResult> DeleteMovie(int id)
        {
            var movieModel = await _context.Movies.FindAsync(id);
            if (movieModel == null)
            {
                return NotFound();
            }

            _context.Movies.Remove(movieModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool MovieModelExists(int id)
        {
            return _context.Movies.Any(e => e.Id == id);
        }
    }
}
